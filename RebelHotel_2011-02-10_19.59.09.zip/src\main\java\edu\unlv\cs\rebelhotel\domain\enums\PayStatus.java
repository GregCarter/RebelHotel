package edu.unlv.cs.rebelhotel.domain.enums;


public enum PayStatus {

    PAID, UNPAID, VOLUNTEER;
}
