package edu.unlv.cs.rebelhotel.domain;

public class Test {
}
