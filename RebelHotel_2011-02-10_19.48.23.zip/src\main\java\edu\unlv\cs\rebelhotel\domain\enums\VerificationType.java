package edu.unlv.cs.rebelhotel.domain.enums;


public enum VerificationType {

    PAY_STUB, BUSINESS_CARD, LETTERHEAD;
}
