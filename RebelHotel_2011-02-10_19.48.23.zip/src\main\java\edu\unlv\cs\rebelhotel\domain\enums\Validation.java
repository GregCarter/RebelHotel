package edu.unlv.cs.rebelhotel.domain.enums;


public enum Validation {

    NO_VALIDATION, PENDING, VALIDATED, FAILED_VALIDATION;
}
