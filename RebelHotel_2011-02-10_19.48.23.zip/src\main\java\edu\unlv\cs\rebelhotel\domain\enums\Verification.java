package edu.unlv.cs.rebelhotel.domain.enums;


public enum Verification {

    ACCEPTED, DENIED;
}
